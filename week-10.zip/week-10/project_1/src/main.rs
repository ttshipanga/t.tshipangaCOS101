struct Laptop {
    brand: String,
    price: u32
}


impl Laptop {
    fn total_price(&self, quantity: u32) -> u32 {
        self.price * quantity
    }
}
fn main() {
   let quantity_purchased: u32 = 3;

   let hp = Laptop {
    brand: String::from("HP"),
    price: 650_000
   };
   let ibm = Laptop {
    brand: String::from("IBM"),
    price: 755_000
   };
   let toshiba = Laptop {
    brand: String::from("Toshiba"),
    price: 550_000
   };
   let dell = Laptop {
    brand: String::from("Dell"),
    price: 850_000
   };

   let laptops = vec![hp, ibm, toshiba, dell];
   let mut total: u32 = 0;
   println!("Amount of laptops purchased {} ", quantity_purchased);

for laptop in &laptops {
    let total_price = laptop.total_price(quantity_purchased);
    println!("Brand: {} \n Price: {} \n Total Price: {}", laptop.brand, laptop.price, total_price);
    total += total_price;
}
   println!("Total price for laptops is {}", total);
}